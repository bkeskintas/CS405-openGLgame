#ifndef WINDOW_H
#define WINDOW_H
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include "camera.h"
using namespace std;




class Window
{
public:
    static bool init(unsigned width, unsigned height, const char* name);
    static GLFWwindow * Return();
    static bool isClosed();
    static void swapBuffersAndPollEvents();
    static GLFWwindow* window;

private:
    Window();
};

GLFWwindow* Window::window = nullptr;

bool Window::init(unsigned width, unsigned height, const char* name)
{
    if (window != nullptr) return true;

    // init glfw
    if (!glfwInit())
    {
        cout << "Failed to initialize GLFW!" << endl;
        return false;
    }

    // glfw window hints

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    // glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);

    window = glfwCreateWindow(width, height, name, NULL, NULL);

    if (window == NULL)
    {
        cout << "Failed to create GLFW window" << endl;
        return false;
    }

    glfwMakeContextCurrent(window);

    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // init glad
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        cout << "Failed to initialize GLAD" << endl;
        return false;
    }

    glEnable(GL_DEPTH_TEST);


    
    return true;
}

bool Window::isClosed() {
    return glfwWindowShouldClose(window);
}

GLFWwindow *  Window::Return() 
{
    return window;
}


void Window::swapBuffersAndPollEvents() {
    glfwSwapBuffers(window);
    glfwPollEvents();
}



void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

#endif