/*
#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>
#include "Window.h"

using namespace std;

*/

/*

const int WIDTH = 800;
const int HEIGHT = 600;

int main(void)
{
    if (!glfwInit()) //library initialization
        return -1;

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "Hello World", NULL, NULL); // windowu �al��t�r�yor
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window); //OpenGl state machine. Current state'de miyiz? Ona bak�yoruz.


    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) // OpenGl functionlar�n� map ediyor. Y�kl�yor open gl functionlar� adresi al�p.
    {
        cout << "Failed to initialize GLAD" << endl;
        return -1;
    }


    glViewport(0, 0, WIDTH, HEIGHT);

    const float positions[18] = {
        -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
        0.0f, 0.5f, -0.0f
    };



    unsigned int buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);  //select this buffer. No need draw buffer func. Automatic working.
    glBufferData(GL_ARRAY_BUFFER, sizeof(positions), positions, GL_STATIC_DRAW); // se�ili olan buffere datay� y�kl�yor

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 3, 0); // pointleri y�kle, bilgi ver layouta
    glEnableVertexAttribArray(0); //layout in shader

    while (!glfwWindowShouldClose(window))  //Bitene kadar i�lemleri burada yap�caz. Olabildi�ince h�zl� efficient olmal�. B�t�n olu�turdu�umuz frameler burada oluturulacak. Ne kadar h�zl�
        // yarat�rsak o kadar fresh rate art�yor. Close button. Buras�.
    {
        glClear(GL_COLOR_BUFFER_BIT); // her seferinde 0l�yoruz. Burada yeni current hesapl�yoruz.
       
        
        
        glDrawArrays(GL_TRIANGLES, 0, 3); //burada 0 dan ba�lay�p 3 �n� �al��t�r diyor pos olarak. �lk girdi�imden ba�lay�p ka� tane alaca��m i�in
       
        glfwSwapBuffers(window); // Yenisi haz�r olunca eskisiyle yenisini de�i�tiriyor. Yer de�i�tiriyorlar s�rekli. 

        glfwPollEvents(); //catch user interactions keyboard mouse
    }

    glfwTerminate();
    return 0;
}

*/



/* RECIT5
unsigned int CompileShader(unsigned int type, const char* source)
{
    unsigned int id = glCreateShader(type);
    glShaderSource(id, 1, &source, nullptr);
    glCompileShader(id);

    return id;
}

unsigned int initShader()
{
    const char* vertexShaderSource =
        R"VERTEX(
            #version 330 core
            layout (location = 0) in vec3 aPos;
            layout (location = 1) in vec3 aColor;
            out vec3 vertex_position;
            out vec3 vertex_color;
            void main()
            {
                gl_Position = vec4(aPos.x, aPos.y, aPos.z, 1.0);
                vertex_position = aPos;
                vertex_color = aColor;
            }
        )VERTEX";

    const char* fragmentShaderSource =
        R"FRAG(
           #version 330 core

           in vec3 vertex_position;
           out vec4 FragColor;

           void main()
           {
            FragColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);
           }
        )FRAG";

    unsigned int program = glCreateProgram();
    unsigned int vertexShader = CompileShader(GL_VERTEX_SHADER, vertexShaderSource);
    unsigned int fragmentShader = CompileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);
    glValidateProgram(program);

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return program;
}

int main()
{
    if (!Window::initWindow(800, 800, "my window")) 
    {
        return 0;
    }

    float positions[] = {
        // positons         // colors
        -0.5f, -0.5f, 0.0f, 1.0f, 0.0f, 0.0f,
        0.5f, -0.5f, 0.0f,  0.0f, 1.0f, 0.0f,
        0.0f, 0.5f, 0.0f,   0.0f, 0.0f, 1.0f,
    };

    unsigned int buffer, VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(positions), positions, GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6, 0);

    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 6, (void*)(sizeof(float) * 3));

    unsigned int program = initShader();

    const int time = glGetUniformLocation(program, "time");

    glUseProgram(program);

    unsigned int frame = 0;
    while (!glfwWindowShouldClose(Window::window))
    {
        frame++;
        glClear(GL_COLOR_BUFFER_BIT);

        glDrawArrays(GL_TRIANGLES, 0, 3);

        glUniform1i(time, frame);
        glfwSwapBuffers(Window::window);

        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}

*/

/*
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "glm/glm.hpp"
#include "glm/gtc/constants.hpp"
#include "glm/gtx/rotate_vector.hpp"
#include "glm/gtx/transform.hpp"
#include "glm/common.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "Window.h"
#include "Shader.h"
#include <iostream>
#include <vector>
using namespace std;

// t = [0, 1]
glm::vec2 coordFromT(double t) {
    // [-0.5, 0.5]
    t -= 0.5;

    t *= glm::pi<double>();

    return glm::vec2(cos(t), sin(t));
}

glm::vec3 rotated(double t, double r) {
    glm::dvec3 point = glm::dvec3(coordFromT(t), 0);

    return glm::rotateY(point, r * glm::two_pi<double>());
}

unsigned int VHtoIndex(int v, int h, int max_v, int max_h) {
    return (h % max_h) * max_v + v;
}

int main()
{
    Window::initWindow(800, 800, "my window");
    unsigned int VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    vector<glm::vec3> positions;
    vector<unsigned int> indices;

    const int vertical = 10;
    const int rotation = 10;

    for (int h = 0; h < rotation; h++) {
        for (int v = 0; v < vertical; v++) {
            double t = (double)v / (vertical - 1);
            double r = (double)h / rotation;
            positions.push_back(rotated(t, r));
        }
    }
    for (int r = 0; r < rotation; r++) {
        for (int v = 0; v < vertical - 1; v++) {

            indices.push_back(VHtoIndex(v, r, vertical, rotation));
            indices.push_back(VHtoIndex(v + 1, r, vertical, rotation));
            indices.push_back(VHtoIndex(v, r + 1, vertical, rotation));

            indices.push_back(VHtoIndex(v, r + 1, vertical, rotation));
            indices.push_back(VHtoIndex(v + 1, r, vertical, rotation));
            indices.push_back(VHtoIndex(v + 1, r + 1, vertical, rotation));
        }
    }

    unsigned int buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * positions.size(), positions.data(), GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(float) * 3, 0);

    unsigned int ibo;
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * indices.size(), indices.data(), GL_STATIC_DRAW);

    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    ShaderProgram sp("C:/Users/eyupb/source/repos/OpenGl/vertex.vert", "C:/Users/eyupb/source/repos/OpenGl/frag.frag");

    const int u_transform = glGetUniformLocation(sp.id, "u_transform");

    sp.use();

    long long int frameCount = 0;
    while (!glfwWindowShouldClose(Window::window))
    {
        glClear(GL_COLOR_BUFFER_BIT);

        // transform
        glm::mat4 transform(1.0f);
        transform = glm::translate(transform, glm::vec3(-0.5, 0.5, 0));
        transform = glm::scale(transform, glm::vec3(0.5f, 0.5f, 0.5f));
        transform = glm::rotate(transform, glm::radians(frameCount * 1.0f), glm::vec3(0, 1, 0));

        glUniformMatrix4fv(u_transform, 1, GL_FALSE, glm::value_ptr(transform));

        // DRAW
        glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, nullptr);

        glfwSwapBuffers(Window::window);

        glfwPollEvents();
        frameCount++;
    }

    glfwTerminate();

    return 0;
}

*/



#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "glm/glm.hpp"
#include "glm/gtc/constants.hpp"
#include "glm/gtx/rotate_vector.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include "glm/gtx/transform.hpp"
#include "glm/common.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "Window.h"
#include "VAO.hpp"
#include "Shader.h"
#include "Parametric3DShape.hpp"
#include <iostream>
#include <vector>


#include "camera.h"


using namespace std;




// Globals
unsigned width = 800, height = 800;
bool increaseX1 = false;


bool firstMouse = true;

Camera camera(glm::vec3(0.0f, 0.0f, -3.0f));
float lastX = width / 2.0f;
float lastY = height / 2.0f;


int u_transform;
float X1 = 0;
float Y1 = 0;
float X2 = 0;
float Y2 = 0;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

void processInput(GLFWwindow* window);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

void draw(unsigned frameCount, VAO& object1, VAO& object2, VAO& object3, VAO& object4)
{
    glm::mat4 transform;

    // Draw object 1 at (-0.5, 0.5, 0)
    transform = glm::mat4(1.0f);
    transform = glm::translate(transform, glm::vec3(-0.5 + X1, 0.5 + Y1, -0.6));
    transform = glm::scale(transform, glm::vec3(0.2));
    transform = glm::rotate(transform, glm::radians(frameCount * 0.00f), glm::vec3(1, 1, 0));
    glUniformMatrix4fv(u_transform, 1, GL_FALSE, glm::value_ptr(transform));

    object1.bind();
    glDrawElements(GL_TRIANGLES, object1.getIndicesCount(), GL_UNSIGNED_INT, NULL);

    // Draw object 2 at (0.5, -0.5, 0)
    transform = glm::mat4(1.0f);
    transform = glm::translate(transform, glm::vec3(X1, Y1, 0.6));
    transform = glm::scale(transform, glm::vec3(0.2));
    transform = glm::rotate(transform, glm::radians(frameCount * 0.005f), glm::vec3(1, 1, 0));
    glUniformMatrix4fv(u_transform, 1, GL_FALSE, glm::value_ptr(transform));

    object2.bind();
    glDrawElements(GL_TRIANGLES, object2.getIndicesCount(), GL_UNSIGNED_INT, NULL);

    // Draw object 3 at (-0.5, -0.5, 0)
    transform = glm::mat4(1.0f);
    transform = glm::translate(transform, glm::vec3(-0.5, -0.5, -0.3));
    transform = glm::scale(transform, glm::vec3(0.2));
    transform = glm::rotate(transform, glm::radians(frameCount * 0.005f), glm::vec3(1, 1, 0));
    glUniformMatrix4fv(u_transform, 1, GL_FALSE, glm::value_ptr(transform));

    object3.bind();
    glDrawElements(GL_TRIANGLES, object3.getIndicesCount(), GL_UNSIGNED_INT, NULL);

    // Draw object 4 at (0.5, 0.5, 0)
    transform = glm::mat4(1.0f);
    transform = glm::translate(transform, glm::vec3(0.5, 0.5, 0.2));
    transform = glm::scale(transform, glm::vec3(0.2));
    transform = glm::rotate(transform, glm::radians(frameCount * 0.005f), glm::vec3(1, 1, 0));
    glUniformMatrix4fv(u_transform, 1, GL_FALSE, glm::value_ptr(transform));

    object4.bind();
    glDrawElements(GL_TRIANGLES, object4.getIndicesCount(), GL_UNSIGNED_INT, NULL);
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_W && action == GLFW_PRESS) {
        Y1 += 0.1;
    }
    else if (key == GLFW_KEY_S && action == GLFW_PRESS) {
        Y1 -= 0.1;
    }
    else if (key == GLFW_KEY_A && action == GLFW_PRESS) {
        X1 -= 0.1;
    }
    else if (key == GLFW_KEY_D && action == GLFW_PRESS) {
        increaseX1 = true;
    }
    else if (key == GLFW_KEY_D && action == GLFW_RELEASE) {
        increaseX1 = false;
    }
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}


static void cursorPositionCallback(GLFWwindow* window, double x, double y)
{
    X2 = 2.0 * ((float)x / width) - 1;
    Y2 = 2.0 * (1 - ((float)y / height)) - 1;
}

int main()
{
    Window::init(width, height, "my window");



    //glfwSetKeyCallback(Window::window, keyCallback);
    glfwSetCursorPosCallback(Window::window, cursorPositionCallback);
    glfwSetScrollCallback(Window::window, scroll_callback);

   // glfwSetInputMode(Window::window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    
    glEnable(GL_DEPTH_TEST);
    
    // create objects
    vector<glm::vec3> positions;
    vector<unsigned int> indices;

    Parametric3DShape::generate(positions, indices, ParametricLine::halfCircle, 30, 30);
    VAO sphereHighRes(positions, indices);

    Parametric3DShape::generate(positions, indices, ParametricLine::halfCircle, 15, 15);
    VAO sphereLowRes(positions, indices);

    Parametric3DShape::generate(positions, indices, ParametricLine::circle, 30, 30);
    VAO donut(positions, indices);

    Parametric3DShape::generate(positions, indices, ParametricLine::spikes, 30, 30);
    VAO spikyDonut(positions, indices);

    // create shader
    ShaderProgram sp("C:/Users/eyupb/source/repos/OpenGl/vertex.vert", "C:/Users/eyupb/source/repos/OpenGl/frag.frag");
    u_transform = glGetUniformLocation(sp.id, "u_transform");

    sp.use();
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // only draw vertices
    int x = 1;
    // game loop
    long long unsigned int frameCount = 0;
    while (!Window::isClosed())
    {
        if (increaseX1)
            X1 += 0.01;
        
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;


        processInput(Window::window);

        glClearColor(  0.0f, 0.0f, 0.4f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)width / (float)height, 0.1f, 100.0f);
        sp.setMat4("projection", projection);

        // camera/view transformation
        glm::mat4 view = camera.GetViewMatrix();
        sp.setMat4("view", view);
        
        // DRAW
        draw(frameCount, sphereHighRes, sphereLowRes, donut, spikyDonut);

        Window::swapBuffersAndPollEvents();
        frameCount++;
    }

    glfwTerminate();

    return 0;
}

void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
}


